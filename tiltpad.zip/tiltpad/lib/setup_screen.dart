import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';

import 'app_info.dart';
import 'connection.dart';
import 'pad/layout.dart';

class SetupScreen extends StatefulWidget {
  const SetupScreen({super.key, required this.onConnect});

  final void Function(String link) onConnect;

  @override
  State<SetupScreen> createState() => _SetupScreenState();
}

class _SetupScreenState extends State<SetupScreen> {
  final _text = TextEditingController();
  String _error = '';

  @override
  void dispose() {
    _text.dispose();
    super.dispose();
  }

  void _submit(String raw) {
    if (!PcConnection.isValidLink(raw)) {
      setState(() => _error = "That doesn't look like the $kAppName link.");
      return;
    }
    widget.onConnect(raw.trim());
  }

  Future<void> _scan() async {
    final code = await Navigator.of(context).push<String>(
      MaterialPageRoute(builder: (_) => const _ScannerPage()),
    );
    if (code != null) _submit(code);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: PadColors.bg,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(32),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 820),
              child: Wrap(
                spacing: 48,
                runSpacing: 24,
                alignment: WrapAlignment.center,
                crossAxisAlignment: WrapCrossAlignment.start,
                children: [
                  SizedBox(
                    width: 340,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(kAppName, style: Theme.of(context).textTheme.displaySmall?.copyWith(fontWeight: FontWeight.bold)),
                        const SizedBox(height: 12),
                        const Text(
                          'Run server.py (or start.bat) on your PC, then scan the QR code it prints in the console. '
                          'Phone and PC must be on the same Wi-Fi.',
                          style: TextStyle(color: PadColors.dim),
                        ),
                        const SizedBox(height: 16),
                        FilledButton.icon(
                          onPressed: _scan,
                          icon: const Icon(Icons.qr_code_scanner),
                          label: const Text('Scan QR code'),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    width: 340,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Or paste the link', style: TextStyle(color: PadColors.dim)),
                        const SizedBox(height: 8),
                        TextField(
                          controller: _text,
                          autocorrect: false,
                          keyboardType: TextInputType.url,
                          decoration: const InputDecoration(
                            hintText: 'https://192.168.x.x:8443/?k=...',
                            border: OutlineInputBorder(),
                          ),
                          onSubmitted: _submit,
                        ),
                        const SizedBox(height: 8),
                        OutlinedButton(onPressed: () => _submit(_text.text), child: const Text('Connect')),
                        if (_error.isNotEmpty)
                          Padding(
                            padding: const EdgeInsets.only(top: 8),
                            child: Text(_error, style: const TextStyle(color: PadColors.b, fontSize: 12)),
                          ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _ScannerPage extends StatefulWidget {
  const _ScannerPage();

  @override
  State<_ScannerPage> createState() => _ScannerPageState();
}

class _ScannerPageState extends State<_ScannerPage> {
  final _ctrl = MobileScannerController(
    formats: const [BarcodeFormat.qrCode],
    detectionSpeed: DetectionSpeed.noDuplicates,
  );
  bool _done = false;

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  void _onDetect(BarcodeCapture capture) {
    if (_done) return;
    for (final b in capture.barcodes) {
      final v = b.rawValue;
      if (v != null && v.isNotEmpty) {
        _done = true;
        Navigator.of(context).pop(v);
        return;
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          Positioned.fill(child: MobileScanner(controller: _ctrl, onDetect: _onDetect)),
          Positioned(
            top: 16,
            right: 16,
            child: SafeArea(
              child: FilledButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Close')),
            ),
          ),
        ],
      ),
    );
  }
}
