import 'package:flutter/material.dart';

import 'pad/layout.dart';
import 'settings.dart';

class SettingsPanel extends StatelessWidget {
  const SettingsPanel({
    super.key,
    required this.settings,
    required this.onClose,
    required this.onChangePc,
  });

  final Settings settings;
  final VoidCallback onClose;
  final VoidCallback onChangePc;

  @override
  Widget build(BuildContext context) {
    return ColoredBox(
      color: const Color(0xEB0A0C0F),
      child: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 560),
            child: Material(
              color: PadColors.panel,
              borderRadius: BorderRadius.circular(16),
              clipBehavior: Clip.antiAlias,
              child: ListenableBuilder(
                listenable: settings,
                builder: (context, _) => SingleChildScrollView(
                  padding: const EdgeInsets.fromLTRB(20, 12, 20, 16),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      _row('Gyro mode', _drop<GyroMode>(settings.mode, {
                        GyroMode.aim: 'Aim camera (right stick)',
                        GyroMode.steer: 'Steering (tilt like a wheel)',
                        GyroMode.off: 'Off',
                      }, (v) => settings.update((s) => s.mode = v))),
                      _row('Gyro active', _drop<GyroGate>(settings.gate, {
                        GyroGate.always: 'Always',
                        GyroGate.lt: 'While holding LT',
                        GyroGate.rt: 'While holding RT',
                        GyroGate.lb: 'While holding LB',
                        GyroGate.rb: 'While holding RB',
                      }, (v) => settings.update((s) => s.gate = v))),
                      if (settings.mode == GyroMode.aim)
                        _row('Horizontal aim from', _drop<YawSource>(settings.yaw, {
                          YawSource.auto: 'Auto (any grip)',
                          YawSource.beta: 'Turning (yaw)',
                          YawSource.alpha: 'Twisting (roll)',
                        }, (v) => settings.update((s) => s.yaw = v))),
                      _row(
                        'Sensitivity',
                        Slider(
                          value: settings.sens.clamp(0.2, 4.0).toDouble(),
                          min: 0.2,
                          max: 4,
                          divisions: 38,
                          label: settings.sens.toStringAsFixed(1),
                          onChanged: (v) => settings.update((s) => s.sens = v),
                        ),
                      ),
                      _switch('Invert horizontal', settings.invX, (v) => settings.update((s) => s.invX = v)),
                      _switch('Invert vertical', settings.invY, (v) => settings.update((s) => s.invY = v)),
                      _switch('Button haptics', settings.tapHaptics, (v) => settings.update((s) => s.tapHaptics = v)),
                      _switch('Game rumble', settings.rumble, (v) => settings.update((s) => s.rumble = v)),
                      _switch('Show ping / frame time', settings.showStats, (v) => settings.update((s) => s.showStats = v)),
                      const SizedBox(height: 8),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          FilledButton(onPressed: onClose, child: const Text('Done')),
                          const SizedBox(width: 12),
                          OutlinedButton(onPressed: onChangePc, child: const Text('Change PC')),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _row(String label, Widget control) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 2),
        child: Row(
          children: [
            Expanded(flex: 4, child: Text(label)),
            Expanded(flex: 5, child: control),
          ],
        ),
      );

  Widget _switch(String label, bool value, ValueChanged<bool> onChanged) => SwitchListTile(
        contentPadding: EdgeInsets.zero,
        dense: true,
        title: Text(label),
        value: value,
        onChanged: onChanged,
      );

  Widget _drop<T>(T value, Map<T, String> items, ValueChanged<T> onChanged) => DropdownButton<T>(
        isExpanded: true,
        value: value,
        underline: const SizedBox.shrink(),
        items: [for (final e in items.entries) DropdownMenuItem(value: e.key, child: Text(e.value))],
        onChanged: (v) {
          if (v != null) onChanged(v);
        },
      );
}
