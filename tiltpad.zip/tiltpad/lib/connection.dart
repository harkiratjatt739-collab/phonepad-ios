import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';

enum LinkState { connecting, connected }

/// Native WebSocket to the PC server (self-signed TLS accepted for the PC's host only).
/// Wire protocol is the same JSON the original PhonePad used.
class PcConnection {
  final ValueNotifier<LinkState> state = ValueNotifier(LinkState.connecting);

  /// Round-trip time in ms, or -1 when unknown (needs the updated server.py).
  final ValueNotifier<int> pingMs = ValueNotifier(-1);

  void Function(int large, int small)? onRumble;

  Uri? _uri;
  WebSocket? _ws;
  bool _active = false;
  Timer? _pingTimer;
  Timer? _retryTimer;
  String _last = '';
  int _backoffMs = 250;

  String get host => _uri?.host ?? '';

  /// True if [link] looks like the https://ip:8443/?k=TOKEN link the PC prints.
  static bool isValidLink(String link) {
    final u = Uri.tryParse(link.trim());
    final k = u?.queryParameters['k'];
    return u != null && u.host.isNotEmpty && k != null && k.isNotEmpty;
  }

  /// [pageUrl] is the https://ip:8443/?k=TOKEN link from the QR code. Returns false if invalid.
  bool start(String pageUrl) {
    final u = Uri.tryParse(pageUrl.trim());
    final k = u?.queryParameters['k'];
    if (u == null || u.host.isEmpty || k == null || k.isEmpty) return false;
    _uri = Uri(
      scheme: 'wss',
      host: u.host,
      port: u.hasPort ? u.port : 443,
      path: '/ws',
      queryParameters: {'k': k},
    );
    _active = true;
    _open();
    return true;
  }

  Future<void> _open() async {
    if (!_active || _uri == null) return;
    final uri = _uri!;
    state.value = LinkState.connecting;
    final client = HttpClient()
      ..connectionTimeout = const Duration(seconds: 4)
      ..badCertificateCallback = (cert, host, port) => host == uri.host;
    try {
      final ws = await WebSocket.connect(
        uri.toString(),
        customClient: client,
        compression: CompressionOptions.compressionOff,
      );
      if (!_active) {
        ws.close();
        return;
      }
      ws.pingInterval = const Duration(seconds: 5);
      _ws = ws;
      _last = '';
      _backoffMs = 250;
      state.value = LinkState.connected;
      _pingTimer?.cancel();
      _pingTimer = Timer.periodic(const Duration(seconds: 2), (_) => _ping());
      _ping();
      ws.listen(
        _onData,
        onDone: () => _lost(ws),
        onError: (_) => _lost(ws),
        cancelOnError: true,
      );
    } catch (_) {
      _lost(null);
    }
  }

  void _lost(WebSocket? ws) {
    if (ws != null && !identical(ws, _ws)) return;
    _ws = null;
    _pingTimer?.cancel();
    pingMs.value = -1;
    state.value = LinkState.connecting;
    if (!_active) return;
    _retryTimer?.cancel();
    _retryTimer = Timer(Duration(milliseconds: _backoffMs), _open);
    _backoffMs = (_backoffMs * 2).clamp(250, 2000).toInt();
  }

  void _ping() {
    _ws?.add('{"t":"p","n":${DateTime.now().millisecondsSinceEpoch}}');
  }

  void _onData(dynamic data) {
    if (data is! String) return;
    try {
      final m = jsonDecode(data);
      if (m is! Map) return;
      switch (m['t']) {
        case 'r':
          onRumble?.call((m['l'] as num?)?.toInt() ?? 0, (m['s'] as num?)?.toInt() ?? 0);
        case 'p':
          final n = (m['n'] as num?)?.toInt();
          if (n != null) pingMs.value = DateTime.now().millisecondsSinceEpoch - n;
      }
    } catch (_) {}
  }

  /// Sends only when the payload changed since the last send.
  void sendIfChanged(String payload) {
    final ws = _ws;
    if (ws == null || payload == _last) return;
    _last = payload;
    ws.add(payload);
  }

  void stop() {
    _active = false;
    _pingTimer?.cancel();
    _retryTimer?.cancel();
    _ws?.close();
    _ws = null;
  }
}
