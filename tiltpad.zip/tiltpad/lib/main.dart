import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'app_info.dart';
import 'pad/layout.dart';
import 'pad/pad_screen.dart';
import 'settings.dart';
import 'setup_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations(
    [DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight],
  );
  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  final settings = await Settings.load();
  runApp(TiltPadApp(settings: settings));
}

class TiltPadApp extends StatefulWidget {
  const TiltPadApp({super.key, required this.settings});

  final Settings settings;

  @override
  State<TiltPadApp> createState() => _TiltPadAppState();
}

class _TiltPadAppState extends State<TiltPadApp> {
  Settings get _s => widget.settings;

  void _setPc(String url) => setState(() => _s.update((s) => s.pcUrl = url));

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: kAppName,
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(seedColor: PadColors.gyro, brightness: Brightness.dark),
        scaffoldBackgroundColor: PadColors.bg,
      ),
      home: _s.pcUrl.isEmpty
          ? SetupScreen(onConnect: _setPc)
          : PadScreen(
              key: ValueKey(_s.pcUrl),
              settings: _s,
              onChangePc: () => _setPc(''),
            ),
    );
  }
}
