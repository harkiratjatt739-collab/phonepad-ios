import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

enum GyroMode { off, aim, steer }

enum GyroGate { always, lt, rt, lb, rb }

enum YawSource { auto, beta, alpha }

/// User settings, persisted with shared_preferences.
class Settings extends ChangeNotifier {
  Settings._(this._p) {
    mode = _enum(GyroMode.values, 'mode', GyroMode.aim);
    gate = _enum(GyroGate.values, 'gate', GyroGate.always);
    yaw = _enum(YawSource.values, 'yaw', YawSource.auto);
    sens = _p.getDouble('sens') ?? 1.0;
    invX = _p.getBool('invX') ?? false;
    invY = _p.getBool('invY') ?? false;
    tapHaptics = _p.getBool('tapHaptics') ?? true;
    rumble = _p.getBool('rumble') ?? true;
    showStats = _p.getBool('showStats') ?? false;
    pcUrl = _p.getString('pcUrl') ?? '';
  }

  final SharedPreferences _p;

  late GyroMode mode;
  late GyroGate gate;
  late YawSource yaw;
  late double sens;
  late bool invX;
  late bool invY;
  late bool tapHaptics;
  late bool rumble;
  late bool showStats;
  late String pcUrl;

  static Future<Settings> load() async => Settings._(await SharedPreferences.getInstance());

  T _enum<T extends Enum>(List<T> values, String key, T def) {
    final name = _p.getString(key);
    for (final v in values) {
      if (v.name == name) return v;
    }
    return def;
  }

  void update(void Function(Settings s) change) {
    change(this);
    _p.setString('mode', mode.name);
    _p.setString('gate', gate.name);
    _p.setString('yaw', yaw.name);
    _p.setDouble('sens', sens);
    _p.setBool('invX', invX);
    _p.setBool('invY', invY);
    _p.setBool('tapHaptics', tapHaptics);
    _p.setBool('rumble', rumble);
    _p.setBool('showStats', showStats);
    _p.setString('pcUrl', pcUrl);
    notifyListeners();
  }
}
