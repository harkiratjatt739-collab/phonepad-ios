/// Change the name here (and in setup.py's APP_NAME / APP_ID) to rebrand the app.
const String kAppName = 'TiltPad';
