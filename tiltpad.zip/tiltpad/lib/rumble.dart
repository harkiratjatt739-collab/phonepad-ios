import 'dart:async';
import 'dart:math' as math;

import 'package:vibration/vibration.dart';

/// Maps game rumble (0-255 per motor) onto the phone's vibration motor.
class Rumble {
  bool _hasVibrator = false;
  bool _hasAmplitude = false;
  Timer? _refresh;
  int _level = 0;
  int _lastFired = 0;
  bool enabled = true;

  Future<void> init() async {
    try {
      _hasVibrator = (await Vibration.hasVibrator()) == true;
      _hasAmplitude = (await Vibration.hasAmplitudeControl()) == true;
    } catch (_) {
      _hasVibrator = false;
    }
  }

  void set(int large, int small) {
    if (!_hasVibrator || !enabled) return;
    final level = math.max(large, small);
    if (level <= 10) {
      stop();
      return;
    }
    _level = level;
    if (_refresh == null || (level - _lastFired).abs() > 30) _fire();
    _refresh ??= Timer.periodic(const Duration(milliseconds: 900), (_) => _fire());
  }

  void _fire() {
    _lastFired = _level;
    Vibration.vibrate(
      duration: 1000,
      amplitude: _hasAmplitude ? _level.clamp(1, 255).toInt() : -1,
    );
  }

  void stop() {
    _refresh?.cancel();
    _refresh = null;
    _level = 0;
    _lastFired = 0;
    if (_hasVibrator) Vibration.cancel();
  }
}
