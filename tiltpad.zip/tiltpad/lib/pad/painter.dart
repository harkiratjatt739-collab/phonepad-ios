import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/widgets.dart';

import '../connection.dart';
import 'layout.dart';
import 'model.dart';

/// Draws the whole controller on one canvas. Repaints are driven by [model] and the link
/// state; there is no widget tree to rebuild while playing, which keeps frame times tiny.
class PadPainter extends CustomPainter {
  PadPainter(this.model, this.layout, this.link) : super(repaint: Listenable.merge([model, link]));

  final PadModel model;
  final PadLayout layout;
  final ValueListenable<LinkState> link;

  final Paint _fill = Paint()..style = PaintingStyle.fill;
  final Paint _stroke = Paint()
    ..style = PaintingStyle.stroke
    ..strokeWidth = 2;
  final Map<StickSpec, Paint> _stickShaders = {};
  final Map<int, TextPainter> _text = {};

  @override
  void paint(Canvas canvas, Size size) {
    for (final b in layout.buttons) {
      _button(canvas, b);
    }
    for (final s in layout.sticks) {
      _stick(canvas, s);
    }
    _dpad(canvas, layout.dpad);
    for (final a in layout.actions) {
      _action(canvas, a);
    }
    _fill.color = link.value == LinkState.connected ? PadColors.a : PadColors.b;
    canvas.drawCircle(layout.dotCenter, 4, _fill);
  }

  void _button(Canvas canvas, ButtonSpec b) {
    final on = model.isDown(b.id);
    final round = b.shape == BtnShape.circle;
    final RRect rr = round
        ? RRect.fromRectAndRadius(b.rect, Radius.circular(b.rect.width / 2))
        : RRect.fromRectAndRadius(b.rect, Radius.circular(math.min(b.corner, b.rect.shortestSide / 2)));
    if (b.fill != null) {
      _fill.color = on ? Color.lerp(b.fill, const Color(0xFFFFFFFF), .4)! : b.fill!;
      canvas.drawRRect(rr, _fill);
      if (on) {
        _stroke
          ..color = PadColors.ink
          ..strokeWidth = 3;
        canvas.drawRRect(rr.inflate(1.5), _stroke);
      }
    } else {
      _fill.color = on ? PadColors.pressed : PadColors.panel;
      canvas.drawRRect(rr, _fill);
      _stroke
        ..color = on ? PadColors.ink : PadColors.edge
        ..strokeWidth = 2;
      canvas.drawRRect(rr.deflate(1), _stroke);
    }
    _label(canvas, b.label, b.rect.center, b.fontSize, b.labelColor ?? PadColors.ink);
  }

  void _stick(Canvas canvas, StickSpec s) {
    final base = _stickShaders.putIfAbsent(
      s,
      () => Paint()
        ..shader = const RadialGradient(colors: [Color(0xFF2B323C), Color(0xFF1B2027)])
            .createShader(Rect.fromCircle(center: s.c, radius: s.r)),
    );
    canvas.drawCircle(s.c, s.r, base);
    _stroke
      ..color = PadColors.edge
      ..strokeWidth = 2;
    canvas.drawCircle(s.c, s.r - 1, _stroke);

    final kx = s.right ? model.rkx : model.lkx;
    final ky = s.right ? model.rky : model.lky;
    final k = s.c + Offset(kx, ky) * (s.r * .55);
    _fill.color = const Color(0xFF4A5566);
    canvas.drawCircle(k, s.r * .46, _fill);
    _stroke
      ..color = const Color(0xFF667286)
      ..strokeWidth = 2;
    canvas.drawCircle(k, s.r * .46 - 1, _stroke);
  }

  void _dpad(Canvas canvas, DpadSpec d) {
    final c = d.rect.width / 3;
    void cell(int col, int row, Btn? id) {
      final on = id != null && model.isDown(id);
      final rr = RRect.fromRectAndRadius(
        Rect.fromLTWH(d.rect.left + col * c, d.rect.top + row * c, c, c),
        const Radius.circular(4),
      );
      _fill.color = on ? PadColors.ink : PadColors.panel;
      canvas.drawRRect(rr, _fill);
      _stroke
        ..color = PadColors.edge
        ..strokeWidth = 2;
      canvas.drawRRect(rr.deflate(1), _stroke);
    }

    cell(1, 0, Btn.up);
    cell(0, 1, Btn.left);
    cell(1, 1, null);
    cell(2, 1, Btn.right);
    cell(1, 2, Btn.down);
  }

  void _action(Canvas canvas, ActionSpec a) {
    final isGyro = a.action == PadAction.gyro;
    final live = isGyro && model.gyroLive;
    final rr = RRect.fromRectAndRadius(a.rect, Radius.circular(a.rect.height / 2));
    _fill.color = live ? PadColors.gyro : PadColors.panel;
    canvas.drawRRect(rr, _fill);
    _stroke
      ..color = live ? PadColors.gyro : PadColors.edge
      ..strokeWidth = 2;
    canvas.drawRRect(rr.deflate(1), _stroke);
    final label = switch (a.action) {
      PadAction.gyro => model.gyroText,
      PadAction.center => 'Center',
      PadAction.settings => 'Settings',
    };
    _label(canvas, label, a.rect.center, 13, live ? const Color(0xFF06201F) : PadColors.ink);
  }

  void _label(Canvas canvas, String s, Offset center, double size, Color color) {
    final tp = _text.putIfAbsent(
      Object.hash(s, size, color),
      () => TextPainter(
        text: TextSpan(
          text: s,
          style: TextStyle(color: color, fontSize: size, fontWeight: FontWeight.w600),
        ),
        textDirection: TextDirection.ltr,
      )..layout(),
    );
    tp.paint(canvas, center - Offset(tp.width / 2, tp.height / 2));
  }

  @override
  bool shouldRepaint(PadPainter old) => old.layout != layout;
}
