import 'dart:ui' show FrameTiming;
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:wakelock_plus/wakelock_plus.dart';

import '../connection.dart';
import '../motion.dart';
import '../rumble.dart';
import '../settings.dart';
import '../settings_panel.dart';
import 'layout.dart';
import 'model.dart';
import 'painter.dart';

class PadScreen extends StatefulWidget {
  const PadScreen({super.key, required this.settings, required this.onChangePc});

  final Settings settings;
  final VoidCallback onChangePc;

  @override
  State<PadScreen> createState() => _PadScreenState();
}

class _PadScreenState extends State<PadScreen> with WidgetsBindingObserver {
  final PadModel _model = PadModel();
  final PcConnection _conn = PcConnection();
  final Rumble _rumble = Rumble();
  late final MotionInput _motion;
  final ValueNotifier<double> _frameMs = ValueNotifier(0);

  bool _gyroOn = true;
  bool _showSettings = false;
  bool _pumping = false;
  double _ms = 0;

  Rect? _area;
  PadLayout? _layout;
  PadPainter? _painter;

  Settings get _s => widget.settings;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    WakelockPlus.enable();
    SchedulerBinding.instance.addTimingsCallback(_onTimings);

    _rumble
      ..enabled = _s.rumble
      ..init();
    _conn.onRumble = (l, sm) {
      _rumble.enabled = _s.rumble;
      _rumble.set(l, sm);
    };
    _model
      ..onPress = _tapHaptic
      ..onAction = _onAction
      ..addListener(_pump);
    _s.addListener(_pump);

    _motion = MotionInput(onSample: _onGyroSample)..start();
    _conn.start(_s.pcUrl);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    SchedulerBinding.instance.removeTimingsCallback(_onTimings);
    WakelockPlus.disable();
    _s.removeListener(_pump);
    _motion.stop();
    _rumble.stop();
    _conn.stop();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state != AppLifecycleState.resumed) {
      _model.releaseAll();
      _rumble.stop();
    }
  }

  void _onTimings(List<FrameTiming> timings) {
    for (final t in timings) {
      _ms = _ms * .9 + (t.totalSpan.inMicroseconds / 1000) * .1;
    }
    if (_s.showStats) _frameMs.value = _ms;
  }

  void _tapHaptic() {
    if (_s.tapHaptics) HapticFeedback.lightImpact();
  }

  void _onAction(PadAction a) {
    switch (a) {
      case PadAction.gyro:
        _gyroOn = !_gyroOn;
        if (_gyroOn && _s.mode == GyroMode.off) _s.update((s) => s.mode = GyroMode.aim);
        _tapHaptic();
      case PadAction.center:
        _motion.calibrate();
        _tapHaptic();
      case PadAction.settings:
        setState(() => _showSettings = true);
    }
  }

  Btn? get _gateBtn => switch (_s.gate) {
        GyroGate.always => null,
        GyroGate.lt => Btn.lt,
        GyroGate.rt => Btn.rt,
        GyroGate.lb => Btn.lb,
        GyroGate.rb => Btn.rb,
      };

  bool get _gyroActive {
    if (!_gyroOn || _s.mode == GyroMode.off) return false;
    final g = _gateBtn;
    return g == null || _model.isDown(g);
  }

  void _onGyroSample() {
    if (_gyroActive) _pump();
  }

  /// Recomputes the controller state and sends it if it changed. Event-driven: runs on touch
  /// events and gyro samples, never on a fixed timer.
  void _pump() {
    if (_pumping) return;
    _pumping = true;
    try {
      final active = _gyroActive;
      final off = !_gyroOn || _s.mode == GyroMode.off;
      _model.setGyro(
        off ? 'Gyro off' : (active ? (_s.mode == GyroMode.steer ? 'Gyro steering' : 'Gyro aiming') : 'Gyro ready'),
        active,
      );
      _conn.sendIfChanged(_encode(active));
    } finally {
      _pumping = false;
    }
  }

  static double _cl(double v) => v < -1 ? -1 : (v > 1 ? 1 : v);
  static double _r3(double v) => (v * 1000).roundToDouble() / 1000;

  String _encode(bool gyroActive) {
    var lx = _model.lx, rx = _model.rx, ry = _model.ry;
    if (gyroActive) {
      final g = _motion.compute(_s);
      if (_s.mode == GyroMode.aim) {
        rx += g.x;
        ry += g.y;
      } else {
        lx += g.x;
      }
    }
    final names = <String>[];
    for (final b in Btn.values) {
      if (b == Btn.lt || b == Btn.rt) continue;
      if (_model.isDown(b)) names.add(b.name.toUpperCase());
    }
    return jsonEncode({
      'b': names,
      'lx': _r3(_cl(lx)),
      'ly': _r3(_model.ly),
      'rx': _r3(_cl(rx)),
      'ry': _r3(_cl(ry)),
      'lt': _model.isDown(Btn.lt) ? 1 : 0,
      'rt': _model.isDown(Btn.rt) ? 1 : 0,
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: PadColors.bg,
      body: LayoutBuilder(builder: (context, c) {
        final pad = MediaQuery.paddingOf(context);
        final area = Rect.fromLTRB(
          pad.left + 8,
          pad.top,
          c.maxWidth - pad.right - 8,
          c.maxHeight - pad.bottom,
        );
        if (_area != area) {
          final hadLayout = _layout != null;
          _area = area;
          _layout = PadLayout.compute(area);
          _model.layout = _layout;
          _painter = PadPainter(_model, _layout!, _conn.state);
          if (hadLayout) WidgetsBinding.instance.addPostFrameCallback((_) => _model.releaseAll());
        }
        return Stack(children: [
          Positioned.fill(
            child: Listener(
              behavior: HitTestBehavior.opaque,
              onPointerDown: (e) => _model.pointerDown(e.pointer, e.localPosition),
              onPointerMove: (e) => _model.pointerMove(e.pointer, e.localPosition),
              onPointerUp: (e) => _model.pointerUp(e.pointer),
              onPointerCancel: (e) => _model.pointerUp(e.pointer),
              child: RepaintBoundary(child: CustomPaint(painter: _painter, size: Size.infinite)),
            ),
          ),
          Positioned(
            top: pad.top + 22,
            left: 0,
            right: 0,
            child: IgnorePointer(
              child: ValueListenableBuilder<LinkState>(
                valueListenable: _conn.state,
                builder: (_, st, __) => st == LinkState.connected
                    ? const SizedBox.shrink()
                    : Center(child: _chip('Connecting to ${_conn.host}…')),
              ),
            ),
          ),
          if (_s.showStats)
            Positioned(
              left: pad.left + 12,
              bottom: pad.bottom + 6,
              child: IgnorePointer(child: _stats()),
            ),
          if (_showSettings)
            Positioned.fill(
              child: SettingsPanel(
                settings: _s,
                onClose: () => setState(() => _showSettings = false),
                onChangePc: widget.onChangePc,
              ),
            ),
        ]);
      }),
    );
  }

  Widget _chip(String text) => DecoratedBox(
        decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(99)),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
          child: Text(text, style: const TextStyle(fontSize: 12, color: PadColors.dim)),
        ),
      );

  Widget _stats() => ListenableBuilder(
        listenable: Listenable.merge([_conn.pingMs, _frameMs]),
        builder: (_, __) {
          final ping = _conn.pingMs.value;
          return _chip('${ping < 0 ? '– ' : '$ping '}ms ping · ${_frameMs.value.toStringAsFixed(1)} ms frame');
        },
      );
}
