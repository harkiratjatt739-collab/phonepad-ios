import 'dart:math' as math;
import 'dart:ui';

import 'package:flutter/foundation.dart';

import 'layout.dart';

/// Live controller state + multitouch routing. Painting listens to this directly,
/// so touch input never triggers a widget rebuild.
class PadModel extends ChangeNotifier {
  PadLayout? layout;

  int mask = 0;
  double lx = 0, ly = 0, rx = 0, ry = 0; // stick output, y up
  double lkx = 0, lky = 0, rkx = 0, rky = 0; // knob position for drawing, y down
  String gyroText = 'Gyro off';
  bool gyroLive = false;

  void Function(PadAction action)? onAction;
  VoidCallback? onPress;

  final Map<int, Object> _owner = {};

  static final int _dpadBits =
      (1 << Btn.up.index) | (1 << Btn.down.index) | (1 << Btn.left.index) | (1 << Btn.right.index);

  bool isDown(Btn b) => mask & (1 << b.index) != 0;

  void setLayout(PadLayout l) {
    layout = l;
    releaseAll();
  }

  void setGyro(String text, bool live) {
    if (text == gyroText && live == gyroLive) return;
    gyroText = text;
    gyroLive = live;
    notifyListeners();
  }

  void releaseAll() {
    _owner.clear();
    mask = 0;
    lx = ly = rx = ry = 0;
    lkx = lky = rkx = rky = 0;
    notifyListeners();
  }

  void pointerDown(int id, Offset p) {
    final t = layout?.hit(p);
    if (t == null) return;
    _owner[id] = t;
    if (t is ButtonSpec) {
      mask |= 1 << t.id.index;
      onPress?.call();
    } else if (t is StickSpec) {
      _moveStick(t, p);
    } else if (t is DpadSpec) {
      onPress?.call();
      _moveDpad(t, p);
    } else if (t is ActionSpec) {
      onAction?.call(t.action);
    }
    notifyListeners();
  }

  void pointerMove(int id, Offset p) {
    final t = _owner[id];
    if (t is StickSpec) {
      _moveStick(t, p);
      notifyListeners();
    } else if (t is DpadSpec) {
      _moveDpad(t, p);
      notifyListeners();
    }
  }

  void pointerUp(int id) {
    final t = _owner.remove(id);
    if (t == null) return;
    if (t is ButtonSpec) {
      if (!_owner.values.any((o) => identical(o, t))) mask &= ~(1 << t.id.index);
    } else if (t is StickSpec) {
      if (t.right) {
        rx = ry = rkx = rky = 0;
      } else {
        lx = ly = lkx = lky = 0;
      }
    } else if (t is DpadSpec) {
      mask &= ~_dpadBits;
    }
    notifyListeners();
  }

  void _moveStick(StickSpec s, Offset p) {
    var dx = (p.dx - s.c.dx) / s.r;
    var dy = (p.dy - s.c.dy) / s.r;
    final m = math.sqrt(dx * dx + dy * dy);
    if (m > 1) {
      dx /= m;
      dy /= m;
    }
    if (s.right) {
      rx = dx;
      ry = -dy;
      rkx = dx;
      rky = dy;
    } else {
      lx = dx;
      ly = -dy;
      lkx = dx;
      lky = dy;
    }
  }

  void _moveDpad(DpadSpec d, Offset p) {
    final c = d.rect.center;
    final r = d.rect.width / 2;
    final dx = (p.dx - c.dx) / r;
    final dy = (c.dy - p.dy) / r;
    final m = math.sqrt(dx * dx + dy * dy);
    var bits = 0;
    if (m > .2) {
      final s = dy / m, co = dx / m;
      if (s > .38) bits |= 1 << Btn.up.index;
      if (s < -.38) bits |= 1 << Btn.down.index;
      if (co > .38) bits |= 1 << Btn.right.index;
      if (co < -.38) bits |= 1 << Btn.left.index;
    }
    mask = (mask & ~_dpadBits) | bits;
  }
}
