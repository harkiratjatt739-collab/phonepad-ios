import 'dart:math' as math;
import 'dart:ui';

/// Virtual Xbox 360 buttons. The enum name (upper-cased) is the wire name the server expects.
enum Btn { a, b, x, y, lb, rb, lt, rt, start, back, guide, l3, r3, up, down, left, right }

enum PadAction { gyro, center, settings }

class PadColors {
  static const bg = Color(0xFF14171C);
  static const panel = Color(0xFF222831);
  static const edge = Color(0xFF323A46);
  static const ink = Color(0xFFE7EBF0);
  static const dim = Color(0xFF7D8794);
  static const pressed = Color(0xFF3A4452);
  static const a = Color(0xFF4FB36A);
  static const b = Color(0xFFE5534B);
  static const x = Color(0xFF4C8DFF);
  static const y = Color(0xFFF0B429);
  static const gyro = Color(0xFF3DD6D0);
  static const faceInk = Color(0xFF101318);
}

enum BtnShape { pill, circle }

class ButtonSpec {
  ButtonSpec(this.id, this.rect, this.shape, this.label,
      {this.fill, this.fontSize = 13, this.labelColor, this.corner = 12});
  final Btn id;
  final Rect rect;
  final BtnShape shape;
  final String label;
  final Color? fill; // face buttons have a solid colour
  final double fontSize;
  final Color? labelColor;
  final double corner;

  bool hit(Offset p) {
    final r = rect.inflate(6);
    if (shape == BtnShape.circle) return (p - r.center).distance <= r.width / 2;
    return r.contains(p);
  }
}

class ActionSpec {
  ActionSpec(this.action, this.rect);
  final PadAction action;
  final Rect rect;
  bool hit(Offset p) => rect.inflate(6).contains(p);
}

class StickSpec {
  StickSpec(this.c, this.r, {required this.right});
  final Offset c;
  final double r;
  final bool right;
  bool hit(Offset p) => (p - c).distance <= r * 1.1;
}

class DpadSpec {
  DpadSpec(this.rect);
  final Rect rect;
  bool hit(Offset p) => rect.inflate(6).contains(p);
}

/// Same arrangement as the original web controller, expressed in the usable screen area.
class PadLayout {
  PadLayout._(this.area, this.buttons, this.sticks, this.dpad, this.actions, this.dotCenter);

  final Rect area;
  final List<ButtonSpec> buttons;
  final List<StickSpec> sticks;
  final DpadSpec dpad;
  final List<ActionSpec> actions;
  final Offset dotCenter;

  factory PadLayout.compute(Rect area) {
    final w = area.width, h = area.height;
    final u = math.min(h / 100, w / 190); // "1 vh", capped so squarer screens don't collide
    final oy = area.top + (h - 100 * u) / 2;
    double px(double pct) => area.left + w * pct / 100;
    double py(double vh) => oy + vh * u;

    final buttons = <ButtonSpec>[];
    Rect sh(double leftPct) => Rect.fromLTWH(px(leftPct), py(3), w * .15, 15 * u);
    buttons
      ..add(ButtonSpec(Btn.lt, sh(4), BtnShape.pill, 'LT'))
      ..add(ButtonSpec(Btn.lb, sh(20), BtnShape.pill, 'LB'))
      ..add(ButtonSpec(Btn.rb, sh(65), BtnShape.pill, 'RB'))
      ..add(ButtonSpec(Btn.rt, sh(81), BtnShape.pill, 'RT'));

    // Face buttons (diamond)
    final fs = 38 * u;
    final fx = px(95) - fs;
    final fy = py(22);
    final d = fs * .42;
    Rect face(double lp, double tp) => Rect.fromLTWH(fx + fs * lp, fy + fs * tp, d, d);
    buttons
      ..add(ButtonSpec(Btn.y, face(.29, 0), BtnShape.circle, 'Y',
          fill: PadColors.y, fontSize: 18, labelColor: PadColors.faceInk))
      ..add(ButtonSpec(Btn.x, face(0, .29), BtnShape.circle, 'X',
          fill: PadColors.x, fontSize: 18, labelColor: PadColors.faceInk))
      ..add(ButtonSpec(Btn.b, face(.58, .29), BtnShape.circle, 'B',
          fill: PadColors.b, fontSize: 18, labelColor: PadColors.faceInk))
      ..add(ButtonSpec(Btn.a, face(.29, .58), BtnShape.circle, 'A',
          fill: PadColors.a, fontSize: 18, labelColor: PadColors.faceInk));

    // Thumb-click buttons
    final sm = 9 * u;
    buttons
      ..add(ButtonSpec(Btn.l3, Rect.fromLTWH(px(6), py(68), sm, sm), BtnShape.circle, 'L3',
          fontSize: 11, labelColor: PadColors.dim))
      ..add(ButtonSpec(Btn.r3, Rect.fromLTWH(px(94) - sm, py(68), sm, sm), BtnShape.circle, 'R3',
          fontSize: 11, labelColor: PadColors.dim));

    // Back / Guide / Start
    final mh = math.max(8 * u, 30.0);
    final bw = math.max(17 * u, 64.0);
    var cx = px(50) - (3 * bw + 20) / 2;
    for (final m in const [('Back', Btn.back), ('Guide', Btn.guide), ('Start', Btn.start)]) {
      buttons.add(ButtonSpec(m.$2, Rect.fromLTWH(cx, py(4), bw, mh), BtnShape.pill, m.$1, corner: 99));
      cx += bw + 10;
    }

    final sticks = [
      StickSpec(Offset(px(5) + 19 * u, py(24) + 19 * u), 19 * u, right: false),
      StickSpec(Offset(px(72) - 36 * u + 18 * u, py(52) + 18 * u), 18 * u, right: true),
    ];
    final dpad = DpadSpec(Rect.fromLTWH(px(27), py(54), 32 * u, 32 * u));

    // Gyro / Center / Settings column
    final ch = math.max(10 * u, 34.0);
    final cw = math.max(26 * u, 110.0);
    final actions = <ActionSpec>[];
    var cy = py(28);
    for (final a in PadAction.values) {
      actions.add(ActionSpec(a, Rect.fromLTWH(px(50) - cw / 2, cy, cw, ch)));
      cy += ch + 10;
    }

    return PadLayout._(area, buttons, sticks, dpad, actions, Offset(px(50), py(1.2) + 4));
  }

  Object? hit(Offset p) {
    for (final a in actions) {
      if (a.hit(p)) return a;
    }
    for (final b in buttons) {
      if (b.hit(p)) return b;
    }
    for (final s in sticks) {
      if (s.hit(p)) return s;
    }
    if (dpad.hit(p)) return dpad;
    return null;
  }
}
