import 'dart:async';
import 'dart:math' as math;

import 'package:sensors_plus/sensors_plus.dart';

import 'settings.dart';

const double _deg = 180 / math.pi;

/// Reads gyro + accelerometer and turns them into stick deflection.
///
/// Conventions (same as the original app): gyro in deg/s about device x/y/z,
/// "up" is the gravity-opposing vector in device coordinates (m/s^2).
class MotionInput {
  MotionInput({required this.onSample});

  /// Called for every gyro sample (so the app can send an update immediately).
  final void Function() onSample;

  double gx = 0, gy = 0, gz = 0;
  double ux = 0, uy = 0, uz = 9.81;
  int _side = 1; // +1: device x points up (landscape A), -1: landscape B
  double _steerZero = 0;
  bool available = true;

  StreamSubscription<GyroscopeEvent>? _gSub;
  StreamSubscription<AccelerometerEvent>? _aSub;

  void start() {
    _gSub = gyroscopeEventStream(samplingPeriod: const Duration(milliseconds: 8)).listen(
      (e) {
        gx = e.x * _deg;
        gy = e.y * _deg;
        gz = e.z * _deg;
        onSample();
      },
      onError: (_) => available = false,
    );
    _aSub = accelerometerEventStream(samplingPeriod: const Duration(milliseconds: 16)).listen(
      (e) {
        const a = 0.25; // low-pass: smooths hand shake but keeps steering responsive
        ux += (e.x - ux) * a;
        uy += (e.y - uy) * a;
        uz += (e.z - uz) * a;
        if (ux > 3) {
          _side = 1;
        } else if (ux < -3) {
          _side = -1;
        }
      },
      onError: (_) => available = false,
    );
  }

  void stop() {
    _gSub?.cancel();
    _aSub?.cancel();
  }

  double _steerRaw() {
    final n = math.sqrt(ux * ux + uy * uy + uz * uz);
    if (n < 1e-3) return 0;
    return math.asin((uy * _side / n).clamp(-1.0, 1.0).toDouble()) * _deg;
  }

  /// "Center" button: current tilt becomes the neutral steering position.
  void calibrate() => _steerZero = _steerRaw();

  double _dz(double v, double sens) {
    final a = v.abs();
    return a < 1.5 ? 0 : v.sign * (a - 1.5) * sens / 90;
  }

  /// Returns (dx, dy) to add to the left (steer) / right (aim) stick.
  ({double x, double y}) compute(Settings s) {
    if (s.mode == GyroMode.aim) {
      final double yawRate;
      switch (s.yaw) {
        case YawSource.auto:
          // Rotation about the world's vertical axis: works however the phone is held.
          final n = math.sqrt(ux * ux + uy * uy + uz * uz);
          yawRate = n < 1e-3 ? 0 : -(gx * ux + gy * uy + gz * uz) / n;
        case YawSource.beta:
          yawRate = -_side * gx;
        case YawSource.alpha:
          yawRate = -_side * gz;
      }
      final pitchRate = -_side * gy;
      return (
        x: _dz(yawRate, s.sens) * (s.invX ? -1 : 1),
        y: _dz(pitchRate, s.sens) * (s.invY ? -1 : 1),
      );
    }
    // Steering: tilt the phone like a wheel.
    var deg = _steerRaw() - _steerZero;
    if (deg.abs() < 3) {
      deg = 0;
    } else {
      deg -= deg.sign * 3;
    }
    final x = (deg / (45 / s.sens)).clamp(-1.0, 1.0).toDouble() * (s.invX ? -1 : 1);
    return (x: x, y: 0);
  }
}
