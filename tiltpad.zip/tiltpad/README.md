# TiltPad

Use your phone (Android or iPhone) as a wireless Xbox 360 controller for Windows, with gyro aiming and steering.
Flutter app + the original Python/ViGEm PC server (`server/`).

## Run it
1. **PC:** install [ViGEmBus](https://github.com/nefarius/ViGEmBus/releases), then run `server/start.bat`. A QR code appears in the console.
2. **App:** install Flutter, then in this folder run `python setup.py` (generates `android/` + `ios/` and patches permissions, landscape lock and min OS versions).
   - Android: `flutter run --release` with a phone plugged in, or `flutter build apk --release`.
   - iPhone: needs a Mac for `flutter build ios`, **or** push this folder to GitHub: `.github/workflows/build.yml` builds an APK and an unsigned `.ipa` (sideload with AltStore/Sideloadly).
3. Open the app, scan the QR code. Same Wi-Fi on both.

The PC server still serves the old browser controller at the same link, so it keeps working as a fallback.

## Why it's fast
- One `CustomPainter` draws the whole pad; touch input repaints only that canvas (no widget rebuilds, no WebView, no JavaScript bridge).
- Raw `Listener` pointer events (no gesture-arena delay), full multi-touch.
- Input is event-driven: a packet goes out on each touch change or gyro sample (~125 Hz), deduplicated, over a native WebSocket with compression off.
- Turn on *Settings -> Show ping / frame time* to see round-trip latency and frame time live.

## Changes vs. the original
- `server/server.py`: 5-line change so the app can measure latency (echoes `{"t":"p"}` probes). Use the updated file; an old server would treat the probe as an empty state.
- Gyro "Auto (any grip)" yaw: uses gravity to find the true vertical axis, so aiming works however you hold the phone.
- Rebrand: name lives in `lib/app_info.dart` and `setup.py` (`APP_NAME`, `APP_ID_ORG`).
