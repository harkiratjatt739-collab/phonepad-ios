"""
One-time setup: generates the android/ and ios/ folders with `flutter create`, then patches in
permissions, landscape lock, app name and minimum OS versions.

    python setup.py          (needs Flutter on PATH: https://docs.flutter.dev/get-started/install)

Then:  flutter run            (debug on a connected phone)
       flutter build apk --release
       flutter build ios --release --no-codesign      (macOS only)
"""
import plistlib
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

APP_NAME = "TiltPad"
APP_ID_ORG = "com.tiltpad"  # final id: com.tiltpad.tiltpad
ROOT = Path(__file__).resolve().parent


def run(*cmd, cwd=ROOT):
    print("$", " ".join(cmd))
    subprocess.run(cmd, cwd=cwd, check=True, shell=(sys.platform == "win32"))


def generate_platforms():
    if (ROOT / "android").exists() and (ROOT / "ios").exists():
        print("android/ and ios/ already exist - only re-applying patches.")
        return
    with tempfile.TemporaryDirectory() as tmp:
        proj = Path(tmp) / "tiltpad"
        run("flutter", "create", "--org", APP_ID_ORG, "--project-name", "tiltpad",
            "--platforms", "android,ios", str(proj))
        for d in ("android", "ios"):
            shutil.copytree(proj / d, ROOT / d, dirs_exist_ok=True)


def patch_android():
    manifest = ROOT / "android/app/src/main/AndroidManifest.xml"
    x = manifest.read_text(encoding="utf-8")
    perms = ["android.permission.INTERNET", "android.permission.CAMERA", "android.permission.VIBRATE"]
    add = "".join(f'    <uses-permission android:name="{p}"/>\n' for p in perms if p not in x)
    if add:
        x = x.replace("<application", add + "    <application", 1)
    x = re.sub(r'android:label="[^"]*"', f'android:label="{APP_NAME}"', x, count=1)
    if "android:screenOrientation" not in x:
        x = x.replace("<activity", '<activity\n            android:screenOrientation="sensorLandscape"', 1)
    manifest.write_text(x, encoding="utf-8")

    for name in ("build.gradle.kts", "build.gradle"):
        g = ROOT / "android/app" / name
        if g.exists():
            t = g.read_text(encoding="utf-8")
            # mobile_scanner needs a newer minSdk than Flutter's default
            t = re.sub(r"minSdk(Version)?(\s*=\s*|\s+)flutter\.minSdkVersion",
                       lambda m: f"minSdk{m.group(1) or ''}{m.group(2)}24", t)
            g.write_text(t, encoding="utf-8")


def patch_ios():
    plist_path = ROOT / "ios/Runner/Info.plist"
    with open(plist_path, "rb") as f:
        p = plistlib.load(f)
    landscape = ["UIInterfaceOrientationLandscapeLeft", "UIInterfaceOrientationLandscapeRight"]
    p["CFBundleDisplayName"] = APP_NAME
    p["CFBundleName"] = APP_NAME
    p["UISupportedInterfaceOrientations"] = landscape
    p["UISupportedInterfaceOrientations~ipad"] = landscape
    p["UIRequiresFullScreen"] = True
    p["UIStatusBarHidden"] = True
    p["NSCameraUsageDescription"] = f"Scan the QR code shown by {APP_NAME} on your PC."
    p["NSLocalNetworkUsageDescription"] = f"{APP_NAME} connects to your PC on your local network to send controller input."
    with open(plist_path, "wb") as f:
        plistlib.dump(p, f)

    podfile = ROOT / "ios/Podfile"
    if podfile.exists():
        t = podfile.read_text(encoding="utf-8")
        t = re.sub(r"^#?\s*platform :ios, '[^']*'", "platform :ios, '15.5'", t, count=1, flags=re.M)
        podfile.write_text(t, encoding="utf-8")
    pbx = ROOT / "ios/Runner.xcodeproj/project.pbxproj"
    if pbx.exists():
        t = pbx.read_text(encoding="utf-8")
        t = re.sub(r"IPHONEOS_DEPLOYMENT_TARGET = [\d.]+;", "IPHONEOS_DEPLOYMENT_TARGET = 15.5;", t)
        pbx.write_text(t, encoding="utf-8")


def main():
    generate_platforms()
    patch_android()
    patch_ios()
    t = ROOT / "test"
    if t.exists():
        shutil.rmtree(t)
    run("flutter", "pub", "get")
    print("\nDone. Plug in a phone and run:  flutter run --release")


if __name__ == "__main__":
    main()
